_author_ = "Liav"
import queue
import socket
import threading
import tkinter as tk
from tkinter import colorchooser, messagebox
from GCM_functions import SecureSession
from key_exchange import dh_client_generate, dh_derive_aes_key
from protocol import recv_msg, recv_secure, send_msg, send_secure

HOST = "127.0.0.1"
PORT = 1234
task_type = ["id", "text", "date", "category", "color", "created_by"]

def fields_to_task(data):
    return {
        "id": data[0],
        "text": data[1],
        "date": data[2],
        "category": data[3],
        "color": data[4],
        "created_by": data[5]
    }


class CyberLegalPad:
    def __init__(self, root):
        self.root = root
        self.root.title("Secure Shared Pad")
        self.root.geometry("760x820")

        self.color_bg = "#FEFBDE"
        self.color_lines = "#2E86C1"
        self.color_margin = "#E53E3E"

        self.catagories = {
            "Cyber Team": "#8E44AD",
            "Development": "#27AE60",
            "Design": "#E67E22",
            "Management": "#C0392B"
        }

        self.selected_catagories = tk.StringVar(root, value="Cyber Team")

        self.sock = None
        self.session = None
        self.username = ""
        self.incoming = queue.Queue()
        self.rows_by_id = {}

        self.show_login_screen()
        self.root.after(100, self.process_incoming)

    def show_login_screen(self):
        for w in self.root.winfo_children():
            w.destroy()

        frame = tk.Frame(self.root, bg="#ecf0f1", padx=35, pady=35)
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text="Secure Shared Task Board", bg="#ecf0f1",
                 font=("Arial", 20, "bold")).pack(pady=(40, 20))

        form = tk.Frame(frame, bg="#ecf0f1")
        form.pack()

        tk.Label(form, text="Username", bg="#ecf0f1").grid(row=0, column=0, sticky="w")
        self.username_entry = tk.Entry(form, width=28)
        self.username_entry.grid(row=1, column=0, pady=(0, 10))

        tk.Label(form, text="Password", bg="#ecf0f1").grid(row=2, column=0, sticky="w")
        self.password_entry = tk.Entry(form, width=28, show="*")
        self.password_entry.grid(row=3, column=0, pady=(0, 15))

        btns = tk.Frame(form, bg="#ecf0f1")
        btns.grid(row=4, column=0)

        tk.Button(btns, text="Login", width=12, bg="#2980b9", fg="white",
                  command=lambda: self.check_user("login")).pack(side="left", padx=5)

        tk.Button(btns, text="Signup", width=12, bg="#27ae60", fg="white",
                  command=lambda: self.check_user("signup")).pack(side="left", padx=5)

        self.status_label = tk.Label(frame, text="Start server.py before logging in",
                                     bg="#ecf0f1", fg="#7f8c8d")
        self.status_label.pack(pady=20)

    def connect(self):
        if self.sock:
            return

        s = socket.socket()
        s.connect((HOST, PORT))
        self.sock = s

        fields = recv_msg(self.sock)
        private_key, client_pub_b64 = dh_client_generate(fields[0])

        send_msg(self.sock, client_pub_b64)

        shared_key = dh_derive_aes_key(private_key, fields[1])
        self.session = SecureSession(shared_key)

    def check_user(self, action):
        usrnm = self.username_entry.get().strip()
        pswrd = self.password_entry.get()

        if not usrnm or not pswrd:
            messagebox.showwarning("Missing details", "Enter username and pswrd")
            return

        try:
            self.connect()
            send_secure(self.sock, self.session, action, usrnm, pswrd)
            reply = recv_secure(self.sock, self.session)

        except Exception as exc:
            self.status_label.config(text=f"Connection failed: {exc}", fg="#c0392b")
            self.sock = None
            return

        if reply[0] != "yes":
            self.status_label.config(text=reply[1], fg="#c0392b")
            return

        self.username = usrnm
        self.show_board()

        threading.Thread(target=self.receive_loop, daemon=True).start()

    def add_task(self):
        text = self.entry.get().strip()
        if not text:
            return

        cat = self.selected_catagories.get()
        color = self.catagories[cat]

        send_secure(
            self.sock, self.session,
            "add_task", text,
            self.date_entry.get(),
            cat, color
        )

        self.entry.delete(0, tk.END)

    def confirm_and_delete(self, task_id, text):
        msg = f"Was this task completed?\n\"{text}\""
        if messagebox.askyesno("Task done", msg):
            send_secure(self.sock, self.session, "delete_task", task_id)

    def delete_row(self, task_id):
        row = self.rows_by_id.pop(task_id, None)
        if not row:
            return

        row.line.destroy()
        row.destroy()

    def receive_loop(self):
        while True:
            try:
                packet = recv_secure(self.sock, self.session)
                self.incoming.put(packet)
            except Exception:
                self.incoming.put(["connection_lost"])
                break

    def process_incoming(self):
        while not self.incoming.empty():
            msg = self.incoming.get()
            t = msg[0]

            if t == "task_added":
                self.render_row(fields_to_task(msg[1:7]))

            elif t == "task_deleted":
                self.delete_row(msg[1])

            elif t == "tasks_list":   # ← FIXED HERE
                count = int(msg[1])
                base = 2
                for i in range(count):
                    start = base + i * 6
                    task = fields_to_task(msg[start:start + 6])
                    self.render_row(task)

            elif t == "user_joined":
                self.root.title(f"{msg[1]} joined")

            elif t == "connection_lost":
                messagebox.showerror("disconnected", "no connection to server")

        self.root.after(100, self.process_incoming)

    def show_board(self):
        for w in self.root.winfo_children():
            w.destroy()

        header = tk.Frame(self.root, bg="#2c3e50", height=50)
        header.pack(fill="x")

        tk.Label(header, text=f"GROUP TASK BOARD - {self.username}",
                 fg="white", bg="#2c3e50", font=("Arial", 14, "bold")).pack(pady=10)

        self.canvas = tk.Canvas(self.root, bg=self.color_bg, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_line(40, 0, 40, 2000, fill=self.color_margin, width=2)

        self.tasks_frame = tk.Frame(self.canvas, bg=self.color_bg)
        self.canvas.create_window((55, 20), window=self.tasks_frame, anchor="nw")

        footer = tk.Frame(self.root, bg="#f4f4f4", pady=15)
        footer.pack(fill="x", side="bottom")

        row1 = tk.Frame(footer, bg="#f4f4f4")
        row1.pack(fill="x", padx=10)

        tk.Label(row1, text="Task:", bg="#f4f4f4").pack(side="left")
        self.entry = tk.Entry(row1, font=("Courier", 10), width=28)
        self.entry.pack(side="left", padx=5)

        tk.Label(row1, text="Date:", bg="#f4f4f4").pack(side="left", padx=(10, 0))
        self.date_entry = tk.Entry(row1, font=("Courier", 10), width=10)
        self.date_entry.pack(side="left", padx=5)

        row2 = tk.Frame(footer, bg="#f4f4f4", pady=5)
        row2.pack(fill="x", padx=10)

        tk.Label(row2, text="Category:", bg="#f4f4f4").pack(side="left")
        self.catagory_menu = tk.OptionMenu(row2, self.selected_catagories, *self.catagories.keys())
        self.catagory_menu.config(width=14)
        self.catagory_menu.pack(side="left", padx=5)

        tk.Button(row2, text="Add category", bg="#8e44ad", fg="white",
                  command=self.open_category_window).pack(side="left", padx=5)

        tk.Button(row2, text="Add to list", bg="#27ae60", fg="white",
                  font=("Arial", 9, "bold"), padx=16,
                  command=self.add_task).pack(side="left", padx=10)

    def open_category_window(self):
        win = tk.Toplevel(self.root)
        win.title("Add Category")
        win.geometry("320x190")
        win.configure(bg="#f4f4f4")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="Category name:", bg="#f4f4f4").pack(pady=(15, 2))
        name_entry = tk.Entry(win, width=25)
        name_entry.pack()
        name_entry.focus_set()

        chosen_color = tk.StringVar(value="#34495E")

        def choose_color():
            win.lift()
            win.focus_force()
            color = colorchooser.askcolor(title="Choose category color",
                                          parent=win, color=chosen_color.get())[1]
            if color:
                chosen_color.set(color)
                preview.config(bg=color)
            win.lift()
            win.focus_force()

        preview = tk.Label(win, text="     ", bg=chosen_color.get())
        preview.pack(pady=5)

        tk.Button(win, text="Choose color", command=choose_color).pack()

        def save_category():
            name = name_entry.get().strip()
            if not name:
                messagebox.showwarning("Missing category", "Enter a category name")
                return
            if name in self.catagories:
                messagebox.showwarning("Category exists", "This category already exists")
                return

            self.catagories[name] = chosen_color.get()
            self.refresh_catagory_menu()
            self.selected_catagories.set(name)
            win.destroy()

        tk.Button(win, text="Create category", bg="#27ae60", fg="white",
                  command=save_category).pack(pady=8)

        win.bind("<Return>", lambda e: save_category())

    def refresh_catagory_menu(self):
        info = self.catagory_menu.pack_info()
        parent = self.catagory_menu.master
        self.catagory_menu.destroy()

        self.catagory_menu = tk.OptionMenu(parent, self.selected_catagories, *self.catagories.keys())
        self.catagory_menu.config(width=14)
        self.catagory_menu.pack(**info)

    def render_row(self, task):
        task_id = task["id"]
        if task_id in self.rows_by_id:
            return

        row = tk.Frame(self.tasks_frame, bg=self.color_bg)
        row.pack(fill="x", anchor="nw")

        tk.Checkbutton(row, bg=self.color_bg, activebackground=self.color_bg,
                       command=lambda: self.confirm_and_delete(task_id, task["text"])
                       ).pack(side="left", padx=(5, 5))

        tk.Label(row, text=" * ", fg=task["color"], bg=self.color_bg,
                 font=("Arial", 12, "bold")).pack(side="left")

        tk.Label(row, text=task["text"], bg=self.color_bg, fg=task["color"],
                 font=("Courier", 13, "bold"), justify="left").pack(side="left", pady=5)

        tk.Label(row, text=f"({task['category']}) | {task['date']} | {task['created_by']}",
                 bg=self.color_bg, fg="#7F8C8D",
                 font=("Courier", 10, "italic")).pack(side="right", padx=20)

        underline = tk.Frame(self.tasks_frame, height=2, bg=self.color_lines)
        underline.pack(fill="x", pady=(0, 5))

        row.line = underline
        self.rows_by_id[task_id] = row

if __name__ == "__main__":
    root = tk.Tk()
    CyberLegalPad(root)
    root.mainloop()
