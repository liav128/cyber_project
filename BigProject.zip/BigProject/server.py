_author_ = "Liav"
import socket
import threading
import uuid
from GCM_functions import SecureSession
from key_exchange import dh_server_generate, dh_derive_aes_key
from protocol import recv_msg, recv_secure, send_msg, send_secure
from users_DB import IsUserExist, IsPasswordOK, SaveUser

HOST = "127.0.0.1"
PORT = 1234

task_types = ["id", "text", "date", "category", "color", "created_by"]

def task_to_data(task):
    return [
        task["id"],
        task["text"],
        task["date"],
        task["category"],
        task["color"],
        task["created_by"]
    ]

def fields_to_task(data):
    return {
        "id": data[0],
        "text": data[1],
        "date": data[2],
        "category": data[3],
        "color": data[4],
        "created_by": data[5]
    }


class TaskServer:
    def __init__(self):
        self.clients = {}
        self.tasks = []
        self.lock = threading.Lock()

    def start(self):
        srv = socket.socket()
        srv.bind((HOST, PORT))
        srv.listen()
        print("server runing")

        while True:
            conn, addr = srv.accept()
            threading.Thread(target=self.handle_client, args=(conn, addr), daemon=True).start()

    def handle_client(self, sock, addr):
        username = None
        try:
            session = self.handshake(sock)
            username = self.check_usrnm(sock, session)

            with self.lock:
                self.clients[sock] = {"username": username, "session": session}
                task_list = list(self.tasks)   # ← renamed

            data = ["tasks_list", str(len(task_list))]  # ← renamed
            for task in task_list:                     # ← renamed
                data += task_to_data(task)

            send_secure(sock, session, *data)

            self.broadcast(None, "user_joined", username)
            print(f"{username} connected from {addr}")

            while True:
                msg = recv_secure(sock, session)
                self.handle_message(sock, username, msg)

        except Exception as exc:
            print(f"{addr} error: {exc}")
        finally:
            self.disconnect(sock, username)

    def handshake(self, sock):
        private_key, params_b64, server_pub_b64 = dh_server_generate()
        send_msg(sock, params_b64, server_pub_b64)
        data = recv_msg(sock)
        aes_key = dh_derive_aes_key(private_key, data[0])
        return SecureSession(aes_key)

    def check_usrnm(self, sock, session):
        while True:
            data = recv_secure(sock, session)
            action = data[0]
            usrnm = data[1].strip()
            pswrd = data[2]

            if action == "signup":
                if IsUserExist(usrnm):
                    usr_verifi, text = "no", "username already used"
                else:
                    SaveUser(usrnm, pswrd, email="")
                    usr_verifi, text = "yes", "account created"

            elif action == "login":
                if IsUserExist(usrnm) and IsPasswordOK(usrnm, pswrd):
                    usr_verifi, text = "yes", "welcome"
                else:
                    usr_verifi, text = "no", "user or password dosent exist "

            else:
                usr_verifi, text = "no", "Use login or signup"

            send_secure(sock, session, usr_verifi, text)

            if usr_verifi == "yes":
                return usrnm

    def handle_message(self, sock, username, data):
        msg_type = data[0]

        if msg_type == "add_task":
            text = data[1].strip()
            if not text:
                return

            task = {
                "id": str(uuid.uuid4()),
                "text": text,
                "date": data[2],
                "category": data[3],
                "color": data[4],
                "created_by": username
            }

            with self.lock:
                self.tasks.append(task)

            self.broadcast(None, "task_added", *task_to_data(task))

        elif msg_type == "delete_task":
            task_id = data[1]

            with self.lock:
                self.tasks = [t for t in self.tasks if t["id"] != task_id]

            self.broadcast(None, "task_deleted", task_id)

    def broadcast(self, exclude, *msg):
        ended = []

        with self.lock:
            snapshot = list(self.clients.items())  # ← unchanged (client list)

        for sock, info in snapshot:
            if sock is exclude:
                continue
            try:
                send_secure(sock, info["session"], *msg)
            except Exception:
                ended.append(sock)

        for sock in ended:
            self.disconnect(sock, None)

    def disconnect(self, sock, username):
        with self.lock:
            entry = self.clients.pop(sock, None)
            if entry and not username:
                username = entry["username"]

        try:
            sock.close()
        except OSError:
            pass

        if username:
            self.broadcast(None, "user_left", username)

if __name__ == "__main__":
    TaskServer().start()
