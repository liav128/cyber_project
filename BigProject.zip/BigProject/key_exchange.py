_author_ = "Liav"
import os
import base64

from cryptography.hazmat.primitives.asymmetric import rsa, padding, dh
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend

RSA_PRIVATE_FILE = "rsa_private.pem"
RSA_PUBLIC_FILE  = "rsa_public.pem"
RSA_PASSWORD     = b"server_rsa_secret"

def rsa_load_or_generate_keys():
    if os.path.exists(RSA_PRIVATE_FILE) and os.path.exists(RSA_PUBLIC_FILE):
        with open(RSA_PRIVATE_FILE, "rb") as f:
            private_key = serialization.load_pem_private_key(
                f.read(), password=RSA_PASSWORD, backend=default_backend()
            )
        with open(RSA_PUBLIC_FILE, "rb") as f:
            public_key = serialization.load_pem_public_key(
                f.read(), backend=default_backend()
            )

        return private_key, public_key


    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    public_key = private_key.public_key()

    pem_private = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.BestAvailableEncryption(RSA_PASSWORD),
    )
    pem_public = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    with open(RSA_PRIVATE_FILE, "wb") as f:
        f.write(pem_private)
    with open(RSA_PUBLIC_FILE, "wb") as f:
        f.write(pem_public)

    return private_key, public_key


def rsa_get_public_key_b64(public_key):
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return base64.b64encode(pem).decode()


def rsa_decrypt_aes_key(private_key, encrypted_b64):
    encrypted = base64.b64decode(encrypted_b64)
    aes_key = private_key.decrypt(
        encrypted,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    return aes_key


def rsa_encrypt_aes_key(public_key_pem_b64, aes_key):
    pem = base64.b64decode(public_key_pem_b64)
    public_key = serialization.load_pem_public_key(pem, backend=default_backend())
    encrypted = public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    return base64.b64encode(encrypted).decode()



#Diffie Hellman

P_HEX = (
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
    "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
    "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
    "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
    "83655D23DCA3AD961C62F356208552BB9ED529077096966D"
    "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9"
    "DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
    "15728E5A8AACAA68FFFFFFFFFFFFFFFF"
)


def dh_parameters():
    p = int(P_HEX, 16)
    g = 2
    pn = dh.DHParameterNumbers(p, g)
    return pn.parameters()


def dh_server_generate():
    parameters = dh_parameters()
    private_key = parameters.generate_private_key()
    public_key  = private_key.public_key()

    params_pem = parameters.parameter_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.ParameterFormat.PKCS3,
    )
    pub_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    return (
        private_key,
        base64.b64encode(params_pem).decode(),
        base64.b64encode(pub_pem).decode(),
    )


def dh_client_generate(params_pem_b64):
    params_pem  = base64.b64decode(params_pem_b64)
    parameters  = serialization.load_pem_parameters(params_pem, backend=default_backend())
    private_key = parameters.generate_private_key()
    public_key  = private_key.public_key()

    pub_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_key, base64.b64encode(pub_pem).decode()


def dh_derive_aes_key(my_private_key, other_public_pem_b64):
    other_pub_pem = base64.b64decode(other_public_pem_b64)
    other_public  = serialization.load_pem_public_key(other_pub_pem, backend=default_backend())

    shared_secret = my_private_key.exchange(other_public)

    aes_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b"handshake data",
    ).derive(shared_secret)

    return aes_key