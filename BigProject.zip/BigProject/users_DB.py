_author_ = "Liav"
import threading
import pickle
import os
import hashlib
import random
import time

USERS_FILE = "users.pkl"
PEPPER_FILE = "pepper.txt"
_users_lock = threading.Lock()
_users = {}
_pending_verifications = {}

with open(PEPPER_FILE, "r") as f:
    peper = f.read().strip()


def load_users():
    global _users
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, "rb") as f:
                _users = pickle.load(f)
        except Exception:
            _users = {}
    else:
        _users = {}


def _save_users():
    with _users_lock:
        with open(USERS_FILE, "wb") as f:
            pickle.dump(_users, f)


load_users()


def IsUserExist(username):
    with _users_lock:
        return username in _users


def IsEmailTaken(email):
    for u in _users.values():
        if u.get('email') == email:
            return True
    if email in _pending_verifications:
        if time.time() < _pending_verifications[email]['expiry']:
            return True
    return False


def IsPasswordOK(username, password):
    with _users_lock:
        if username not in _users: return False
        salt = _users[username]["salt"]
        return _users[username]["pwd"] == hash_password(password, salt)


def generate_salt():
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=32))


def hash_password(password, salt):
    combine = password + salt + peper
    return hashlib.sha256(combine.encode()).hexdigest()


def create_pending_action(email, data, action_type):
    code = str(random.randint(100000, 999999))
    _pending_verifications[email] = {
        'code': code,
        'data': data,
        'type': action_type,
        'expiry': time.time() + 300
    }
    return code


def verify_code(email, code):
    if email not in _pending_verifications:
        return False, "No active request"

    entry = _pending_verifications[email]
    if time.time() > entry['expiry']:
        del _pending_verifications[email]
        return False, "Code expired"

    if entry['code'] == code:
        data = entry['data']
        action_type = entry['type']
        del _pending_verifications[email]
        return True, (action_type, data)

    return False, "Wrong code"


def SaveUser(username, password, email):
    salt = generate_salt()
    pwd_hash = hash_password(password, salt)
    with _users_lock:
        _users[username] = {"pwd": pwd_hash, "salt": salt, "email": email}
    _save_users()


def UpdatePassword(username, new_password):
    if username in _users:
        salt = generate_salt()
        _users[username]["pwd"] = hash_password(new_password, salt)
        _users[username]["salt"] = salt
        _save_users()


def GetUserEmail(username):
    with _users_lock:
        if username in _users:
            return _users[username]["email"]
        return None