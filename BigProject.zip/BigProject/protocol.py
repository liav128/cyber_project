_author_ = "Liav"
import struct
max = 10 * 1024 * 1024
spliter = "|"

def _recv_exact(sock, amount):
    data = bytearray()
    while len(data) < amount:
        chunk = sock.recv(amount - len(data))
        if not chunk:
            raise ConnectionError("socket closed")
        data += (chunk)
    return bytes(data)


def send_bytes(sock, data: bytes):
    sock.sendall(struct.pack("!I", len(data)) + data)


def recv_bytes(sock):
    size = struct.unpack("!I", _recv_exact(sock, 4))[0]
    if size > max:
        raise ValueError("message too large")
    return _recv_exact(sock, size)


def send_msg(sock, *fields):
    send_bytes(sock, spliter.join(fields).encode())


def recv_msg(sock) :
    return recv_bytes(sock).decode().split(spliter)


def send_secure(sock, session, *fields):
    send_bytes(sock, session.encrypt(spliter.join(fields).encode()))


def recv_secure(sock, session) -> list:
    return session.decrypt(recv_bytes(sock)).decode().split(spliter)